<?php
session_start();
require 'db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error = '';
$success = '';
$product_id = '';
$quantity = '';
$total = '';
$sale_id = '';
$receipt_code = '';


if (isset($_GET['product_id'])) {
    $product_id = (int)$_GET['product_id'];
}


$stmt = $conn->prepare("SELECT product_id, product_name, price, stock FROM products WHERE stock > 0 ORDER BY product_name ASC");
$products = array();
if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    $stmt->close();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 0;

    
    if ($product_id <= 0) {
        $error = "Please select a product.";
    } elseif ($quantity <= 0) {
        $error = "Quantity must be greater than zero.";
    } else {
        
        $stmt = $conn->prepare("SELECT product_id, product_name, price, stock FROM products WHERE product_id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $product = $result->fetch_assoc();

                
                if ($product['stock'] < $quantity) {
                    $error = "Insufficient stock. Available: " . $product['stock'];
                } else {
                    
                    $total = $product['price'] * $quantity;

                    
                    $stmt2 = $conn->prepare("INSERT INTO sales (product_id, quantity, sale_date, total) VALUES (?, ?, NOW(), ?)");
                    if ($stmt2) {
                        $stmt2->bind_param("idi", $product_id, $quantity, $total);
                        if ($stmt2->execute()) {
                            $sale_id = $stmt2->insert_id;
                            $receipt_code = "RCP-" . str_pad($sale_id, 6, "0", STR_PAD_LEFT);

                            $stmt3 = $conn->prepare("UPDATE sales SET receipt_code = ? WHERE sale_id = ?");
                            if ($stmt3) {
                                $stmt3->bind_param("si", $receipt_code, $sale_id);
                                $stmt3->execute();
                                $stmt3->close();
                            }

                            $new_stock = $product['stock'] - $quantity;
                            $stmt3 = $conn->prepare("UPDATE products SET stock = ? WHERE product_id = ?");
                            if ($stmt3) {
                                $stmt3->bind_param("ii", $new_stock, $product_id);
                                $stmt3->execute();
                                $stmt3->close();
                            }

                            $success = "Sale recorded successfully!";

                            header("Location: receipt.php?code=" . urlencode($receipt_code));
                            exit();
                        } else {
                            $error = "Error recording sale: " . $stmt2->error;
                        }
                        $stmt2->close();
                    } else {
                        $error = "Database error: " . $conn->error;
                    }
                }
            } else {
                $error = "Product not found.";
            }
            $stmt->close();
        } else {
            $error = "Database error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Sale</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function updatePrice() {
            const productSelect = document.getElementById('product_id');
            const quantityInput = document.getElementById('quantity');
            const totalDisplay = document.getElementById('total_display');
            
            if (productSelect.value && quantityInput.value) {
                const selectedOption = productSelect.options[productSelect.selectedIndex];
                const price = parseFloat(selectedOption.getAttribute('data-price'));
                const quantity = parseInt(quantityInput.value);
                
                if (!isNaN(price) && !isNaN(quantity) && quantity > 0) {
                    const total = (price * quantity).toFixed(2);
                    totalDisplay.textContent = '$' + total;
                    document.getElementById('total_input').value = total;
                } else {
                    totalDisplay.textContent = '$0.00';
                }
            } else {
                totalDisplay.textContent = '$0.00';
            }
        }
    </script>
</head>
<body>
    <header>
        <h1>Store Management System - Record Sale</h1>
    </header>

    <nav>
        <a href="index.php">📦 Inventory</a>
        <a href="add_sale.php">💰 Record Sale</a>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="add_product.php">➕ Add Product</a>
            <a href="product_list.php">✏️ Manage Products</a>
        <?php endif; ?>
        <span style="float: right; padding: 12px 20px;">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            <span class="role-badge <?php echo $_SESSION['role'] === 'admin' ? 'role-admin' : 'role-staff'; ?>">
                <?php echo strtoupper($_SESSION['role']); ?>
            </span>
            | <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
        </span>
    </nav>

    <div class="container">
        <h2 class="page-title">💰 Record New Sale</h2>

        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="message success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="product_id">Product:</label>
            <select id="product_id" name="product_id" required onchange="updatePrice()">
                <option value="">-- Select a Product --</option>
                <?php foreach ($products as $prod): ?>
                    <option value="<?php echo $prod['product_id']; ?>" 
                            data-price="<?php echo $prod['price']; ?>"
                            <?php echo ($product_id == $prod['product_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($prod['product_name']) . " - $" . number_format($prod['price'], 2) . " (Stock: " . $prod['stock'] . ")"; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" min="1" value="<?php echo htmlspecialchars($quantity); ?>" required onchange="updatePrice()" oninput="updatePrice()">

            <label>Total Price:</label>
            <div style="padding: 10px; background-color: #f9f9f9; border: 1px solid #ddd;">
                <span id="total_display">$0.00</span>
            </div>
            <input type="hidden" id="total_input" name="total" value="0.00">

            <button type="submit">Complete Sale</button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="index.php" class="btn btn-secondary">Back to Inventory</a>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>

