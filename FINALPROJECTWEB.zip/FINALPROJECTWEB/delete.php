<?php
session_start();
require 'db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}


$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: product_list.php");
    exit();
}


$stmt = $conn->prepare("SELECT product_id FROM products WHERE product_id = ?");
if (!$stmt) {
    header("Location: product_list.php");
    exit();
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    $stmt->close();
    header("Location: product_list.php");
    exit();
}

$stmt->close();


$stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?");
if ($stmt) {
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

$conn->close();
header("Location: product_list.php");
exit();
?>

