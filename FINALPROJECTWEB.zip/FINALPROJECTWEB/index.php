<?php
session_start();
include 'db.php';


if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$search = '';
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}


$query = "SELECT 
    p.product_id, 
    p.product_name, 
    p.price, 
    p.stock,
    COALESCE(SUM(s.quantity), 0) as total_sold
FROM products p
LEFT JOIN sales s ON p.product_id = s.product_id
WHERE p.product_name LIKE ?
GROUP BY p.product_id, p.product_name, p.price, p.stock
ORDER BY p.product_name ASC";

$stmt = $conn->prepare($query);
if ($stmt) {
    $search_param = "%{$search}%";
    $stmt->bind_param("s", $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = null;
    $error = "Database error: " . $conn->error;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Management - Inventory</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Store Management System - Dashboard</h1>
    </header>

    <nav>
        <a href="index.php">📦 Inventory</a>
        <a href="add_sale.php">💰 Record Sale</a>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="add_product.php">➕ Add Product</a>
            <a href="product_list.php">✏️ Manage Products</a>
        <?php endif; ?>
        <span style="float: right; padding: 12px 20px;">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            <span class="role-badge <?php echo $_SESSION['role'] === 'admin' ? 'role-admin' : 'role-staff'; ?>">
                <?php echo strtoupper($_SESSION['role']); ?>
            </span>
            | <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
        </span>
    </nav>

    <div class="container">
        <h2 class="page-title">📦 Inventory</h2>

        <div class="search-bar">
            <form method="GET" style="display: inline;">
                <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
                <?php if ($search): ?>
                    <a href="index.php" class="btn btn-secondary">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <?php if (isset($error)): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($result && $result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Total Sold</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($product = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                            <td>$<?php echo number_format($product['price'], 2); ?></td>
                            <td><?php echo $product['stock']; ?></td>
                            <td><?php echo $product['total_sold']; ?></td>
                            <td>
                                <a href="add_sale.php?product_id=<?php echo $product['product_id']; ?>" class="btn btn-primary">
                                    Buy
                                </a>
                                <?php if ($_SESSION['role'] === 'admin'): ?>
                                    <a href="edit_product.php?id=<?php echo $product['product_id']; ?>" class="btn btn-edit">
                                        Edit
                                    </a>
                                    <a href="delete_product.php?id=<?php echo $product['product_id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure?');">
                                        Delete
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="message info">No products found.</div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
if ($stmt) {
    $stmt->close();
}
$conn->close();
?>

