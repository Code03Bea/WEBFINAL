<?php
session_start();
require 'db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';


$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: product_list.php");
    exit();
}


$stmt = $conn->prepare("SELECT product_id, product_name, price, stock FROM products WHERE product_id = ?");
if (!$stmt) {
    $error = "Database error: " . $conn->error;
}

$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: product_list.php");
    exit();
}

$product = $result->fetch_assoc();
$product_name = $product['product_name'];
$price = $product['price'];
$stock = $product['stock'];

$stmt->close();


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = isset($_POST['product_name']) ? trim($_POST['product_name']) : '';
    $price = isset($_POST['price']) ? trim($_POST['price']) : '';
    $stock = isset($_POST['stock']) ? trim($_POST['stock']) : '';

    
    if (empty($product_name) || empty($price) || empty($stock)) {
        $error = "All fields are required.";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = "Price must be a positive number.";
    } elseif (!is_numeric($stock) || $stock < 0 || $stock != (int)$stock) {
        $error = "Stock must be a non-negative integer.";
    } else {
        $price = (float)$price;
        $stock = (int)$stock;

        
        $stmt = $conn->prepare("UPDATE products SET product_name = ?, price = ?, stock = ? WHERE product_id = ?");
        if ($stmt) {
            $stmt->bind_param("sdii", $product_name, $price, $stock, $id);
            if ($stmt->execute()) {
                $success = "Product updated successfully!";
            } else {
                $error = "Error updating product: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "Database error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Store Management System - Edit Product</h1>
    </header>

    <nav>
        <a href="index.php">📦 Inventory</a>
        <a href="add_sale.php">💰 Record Sale</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="product_list.php">✏️ Manage Products</a>
        <span style="float: right; padding: 12px 20px;">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            <span class="role-badge role-admin">ADMIN</span>
            | <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
        </span>
    </nav>

    <div class="container">
        <h2 class="page-title">✏️ Edit Product</h2>

        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="message success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" value="<?php echo htmlspecialchars($product_name); ?>" required>

            <label for="price">Price ($):</label>
            <input type="number" id="price" name="price" step="0.01" min="0.01" value="<?php echo $price; ?>" required>

            <label for="stock">Stock:</label>
            <input type="number" id="stock" name="stock" min="0" value="<?php echo $stock; ?>" required>

            <button type="submit">Update Product</button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="product_list.php" class="btn btn-secondary">Back to Products</a>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>

