# Store Management System

A simple PHP-based inventory and sales management web application.

## Prerequisites

- XAMPP (or similar: Apache, MySQL, PHP)
- PHP 5.4+ with mysqli extension
- MySQL 5.6+

## Setup Instructions

1. **Install XAMPP**:
   - Download and install XAMPP from [apachefriends.org](https://www.apachefriends.org/).
   - Start Apache and MySQL from the XAMPP control panel.

2. **Clone the Repository**:
   ```bash
   git clone https://github.com/Code03Bea/FINALPROJECTWEB.git
   cd FINALPROJECTWEB
   ```

3. **Set up the Database**:
   - Open phpMyAdmin at `http://localhost/phpmyadmin`.
   - Create a new database named `store_dban`.
   - Create the following tables (or import from a SQL dump if provided):

     ```sql
     CREATE TABLE products (
         product_id INT AUTO_INCREMENT PRIMARY KEY,
         product_name VARCHAR(255) NOT NULL,
         price DECIMAL(10,2) NOT NULL,
         stock INT NOT NULL
     );

     CREATE TABLE sales (
         sale_id INT AUTO_INCREMENT PRIMARY KEY,
         product_id INT NOT NULL,
         quantity INT NOT NULL,
         sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         FOREIGN KEY (product_id) REFERENCES products(product_id)
     );

     CREATE TABLE users (
         user_id INT AUTO_INCREMENT PRIMARY KEY,
         username VARCHAR(50) UNIQUE NOT NULL,
         password VARCHAR(255) NOT NULL,
         role ENUM('admin', 'user') DEFAULT 'user'
     );
     ```

   - If you prefer, the application can auto-create these tables and seed default credentials on first run when `db.php` is present.
   - The default seeded users are:
     - Admin: `admin` / `1234`
     - Staff: `staff` / `1234`

4. **Configure Database Connection**:
   - Copy `db.example.php` to `db.php`.
   - Update the credentials in `db.php` to match your MySQL setup.

5. **Run the Application**:
   - Place the project folder in `C:\xampp\htdocs\` (or equivalent).
   - Access at `http://localhost/FINALPROJECTWEB/index.php`.
   - Log in with your admin/user credentials.

## Features

- User authentication (login/logout)
- Product management (add, edit, delete)
- Sales tracking
- Inventory overview

## Notes

- Ensure file permissions allow PHP to read/write if needed.
- For production, use environment variables for database credentials instead of hardcoding.
