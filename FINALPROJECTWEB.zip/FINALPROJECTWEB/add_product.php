<?php
session_start();
require 'db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


if ($_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = isset($_POST['product_name']) ? trim($_POST['product_name']) : '';
    $price = isset($_POST['price']) ? trim($_POST['price']) : '';
    $stock = isset($_POST['stock']) ? trim($_POST['stock']) : '';

    
    if (empty($product_name) || empty($price) || empty($stock)) {
        $error = "All fields are required.";
    } elseif (!is_numeric($price) || $price <= 0) {
        $error = "Price must be a positive number.";
    } elseif (!is_numeric($stock) || $stock < 0 || $stock != (int)$stock) {
        $error = "Stock must be a non-negative integer.";
    } else {
        $price = (float)$price;
        $stock = (int)$stock;

        
        $stmt = $conn->prepare("INSERT INTO products (product_name, price, stock) VALUES (?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sdi", $product_name, $price, $stock);
            if ($stmt->execute()) {
                $success = "Product added successfully!";
                $product_name = '';
                $price = '';
                $stock = '';
            } else {
                $error = "Error adding product: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "Database error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Admin</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Store Management System - Add Product</h1>
    </header>

    <nav>
        <a href="index.php">📦 Inventory</a>
        <a href="add_sale.php">💰 Record Sale</a>
        <a href="add_product.php">➕ Add Product</a>
        <a href="product_list.php">✏️ Manage Products</a>
        <span style="float: right; padding: 12px 20px;">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            <span class="role-badge role-admin">ADMIN</span>
            | <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
        </span>
    </nav>

    <div class="container">
        <h2 class="page-title">➕ Add New Product</h2>

        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="message success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" value="<?php echo htmlspecialchars($product_name ?? ''); ?>" required>

            <label for="price">Price ($):</label>
            <input type="number" id="price" name="price" step="0.01" min="0.01" value="<?php echo htmlspecialchars($price ?? ''); ?>" required>

            <label for="stock">Initial Stock:</label>
            <input type="number" id="stock" name="stock" min="0" value="<?php echo htmlspecialchars($stock ?? ''); ?>" required>

            <button type="submit">Add Product</button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="product_list.php" class="btn btn-secondary">View All Products</a>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>

