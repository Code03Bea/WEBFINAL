<?php
session_start();
require 'db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error = '';
$receipt = null;


$receipt_code = isset($_GET['code']) ? trim($_GET['code']) : '';

if ($receipt_code === '') {
    header("Location: add_sale.php");
    exit();
}

$stmt = $conn->prepare("
    SELECT 
        s.sale_id,
        s.receipt_code,
        s.quantity,
        s.total,
        s.sale_date,
        p.product_name,
        p.price
    FROM sales s
    JOIN products p ON s.product_id = p.product_id
    WHERE s.receipt_code = ?
");

if ($stmt) {
    $stmt->bind_param("i", $sale_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $receipt = $result->fetch_assoc();
    } else {
        $error = "Receipt not found.";
    }
    $stmt->close();
} else {
    $error = "Database error: " . $conn->error;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Store Management System - Receipt</h1>
    </header>

    <nav>
        <a href="index.php">📦 Inventory</a>
        <a href="add_sale.php">💰 Record Sale</a>
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="add_product.php">➕ Add Product</a>
            <a href="product_list.php">✏️ Manage Products</a>
        <?php endif; ?>
        <span style="float: right; padding: 12px 20px;">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            <span class="role-badge <?php echo $_SESSION['role'] === 'admin' ? 'role-admin' : 'role-staff'; ?>">
                <?php echo strtoupper($_SESSION['role']); ?>
            </span>
            | <a href="logout.php" style="color: white; text-decoration: none;">Logout</a>
        </span>
    </nav>

    <div class="container">
        <h2 class="page-title">🧾 Receipt</h2>

        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php elseif ($receipt): ?>
            <div class="receipt">
                <div class="receipt-header">
                    <h3>RECEIPT</h3>
                    <div class="receipt-code"><?php echo htmlspecialchars($receipt['receipt_code']); ?></div>
                </div>

                <div class="receipt-detail">
                    <label>Date:</label>
                    <?php echo date('M d, Y H:i', strtotime($receipt['sale_date'])); ?>
                </div>

                <div class="receipt-detail">
                    <label>Product:</label>
                    <?php echo htmlspecialchars($receipt['product_name']); ?>
                </div>

                <div class="receipt-detail">
                    <label>Unit Price:</label>
                    $<?php echo number_format($receipt['price'], 2); ?>
                </div>

                <div class="receipt-detail">
                    <label>Quantity:</label>
                    <?php echo $receipt['quantity']; ?>
                </div>

                <div class="receipt-total">
                    TOTAL: $<?php echo number_format($receipt['total'], 2); ?>
                </div>

                <div style="text-align: center; margin-top: 20px; font-size: 12px; color: #555;">
                    Thank you for your purchase!
                </div>

                <button class="print-btn" onclick="window.print()">🖨️ Print Receipt</button>
            </div>

            <div style="text-align: center; margin-top: 20px;">
                <a href="add_sale.php" class="btn btn-primary">Record Another Sale</a>
                <a href="index.php" class="btn btn-secondary">Back to Inventory</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php $conn->close(); ?>

