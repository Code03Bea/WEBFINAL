<?php

$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'store_dban';

$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, 'utf8');

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10,2) NOT NULL DEFAULT 0,
    receipt_code VARCHAR(20) DEFAULT NULL,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

$result = mysqli_query($conn, "SHOW COLUMNS FROM sales LIKE 'total'");
if ($result && mysqli_num_rows($result) === 0) {
    mysqli_query($conn, "ALTER TABLE sales ADD COLUMN total DECIMAL(10,2) NOT NULL DEFAULT 0");
}

$result = mysqli_query($conn, "SHOW COLUMNS FROM sales LIKE 'receipt_code'");
if ($result && mysqli_num_rows($result) === 0) {
    mysqli_query($conn, "ALTER TABLE sales ADD COLUMN receipt_code VARCHAR(20) DEFAULT NULL");
}

$result = mysqli_query($conn, "SHOW INDEX FROM sales WHERE Key_name = 'receipt_code'");
if ($result && mysqli_num_rows($result) === 0) {
    mysqli_query($conn, "ALTER TABLE sales ADD UNIQUE INDEX receipt_code (receipt_code)");
}

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;");

$admin_password = md5('1234');
$staff_password = md5('1234');
$result = mysqli_query($conn, "SELECT 1 FROM users WHERE username = 'admin' LIMIT 1");
if (!$result || mysqli_num_rows($result) === 0) {
    mysqli_query($conn, "INSERT INTO users (username, password, role) VALUES ('admin', '$admin_password', 'admin')");
} else {
    mysqli_query($conn, "UPDATE users SET password = '$admin_password', role = 'admin' WHERE username = 'admin'");
}

$result = mysqli_query($conn, "SELECT 1 FROM users WHERE username = 'staff' LIMIT 1");
if (!$result || mysqli_num_rows($result) === 0) {
    mysqli_query($conn, "INSERT INTO users (username, password, role) VALUES ('staff', '$staff_password', 'staff')");
} else {
    mysqli_query($conn, "UPDATE users SET password = '$staff_password', role = 'staff' WHERE username = 'staff'");
}

$result = mysqli_query($conn, "SELECT 1 FROM products LIMIT 1");
if ($result && mysqli_num_rows($result) === 0) {
    mysqli_query($conn, "INSERT INTO products (product_name, price, stock) VALUES
        ('Ballpen', 10.00, 100),
        ('Notebook', 50.00, 60),
        ('Pencil', 8.00, 150),
        ('Eraser', 5.00, 200),
        ('Sharpener', 12.00, 80),
        ('Ruler', 15.00, 70),
        ('Marker', 25.00, 90),
        ('Crayons', 40.00, 50),
        ('Folder', 20.00, 65),
        ('Bond Paper (ream)', 250.00, 30),
        ('Glue', 18.00, 85),
        ('Scissors', 35.00, 40),
        ('Highlighter', 22.00, 75),
        ('Correction Tape', 30.00, 55),
        ('Stapler', 60.00, 25)");
}
?>